import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


#edges = pd.read_csv('mammalia.txt', sep=" ", header=None, names=['od', 'do', 'weight'])
edges = pd.read_csv('rt_obama.txt', sep=",", usecols=[0, 1], header=None)

def ssaki():
    weighted_edges = list(zip(edges['od'], edges['do'], edges['weight']))
    G = nx.Graph()
    G.add_weighted_edges_from(weighted_edges)

    return(G,True)

def obama():
    edge_list = edges.values.tolist()
    G = nx.Graph()
    G.add_edges_from(edge_list)
    return(G,False)

G,czy_wagi = obama()

def wizualizacja(G):
    plt.figure(figsize=(10, 10))
    pos = nx.spring_layout(G)
    nx.draw(G, pos, with_labels=True, labels={node: node for node in G.nodes()},
            node_size=500, node_color="lightblue", font_size=10, font_weight="bold",
            edge_color="gray")
    plt.title("Wizualizacja Grafu z oryginalnymi etykietami węzłów", size=15)
    plt.show()

#Podstawowe wlasnosci
def podstawowe_wlasnosci_grafu(G,czy_wagi):
    ile_wierz = G.number_of_nodes()
    ile_kraw = G.size()
    density = nx.density(G)
    try:
        srednica = nx.diameter(G)
    except:
        srednica = "graf jest nie polaczony"
    try:
        srednia_dl_najkrt = nx.average_shortest_path_length(G)
    except:
        srednia_dl_najkrt = "graf nie jest polaczony"

    if czy_wagi == True:
        jakie_wagi = []
        lista = np.array(edges['weight'])
        for i in lista:
            if i not in jakie_wagi:
                jakie_wagi.append(int(i))
    else:
        jakie_wagi = "Graf nie ma wag"


    print(f"\ngraf ma {ile_wierz} wierzcholkow, {ile_kraw} krawedzi i ma nastepujace wagi: {jakie_wagi},"
          f"\nGestosc grafu: {density},\nŚrednica grafu: {srednica},\nSrednia dlugosc najkrotszej sciezki: {srednia_dl_najkrt},\n")


def wlasnosci_wierzcholkow(G,czy_wagi):
    nr_w = int(input("podaj numer wierzcholka dla ktorego chcesz sprawdzic wlasnosci(dla obamy polecam: 967, dla ssakow polecam: 772)\n: "))
    stopien = G.degree(nr_w)

    bliskosc1 = nx.closeness_centrality(G)
    bliskosc = bliskosc1.get(nr_w)

    lista = nx.betweenness_centrality(G)
    posrednictwo = lista.get(nr_w)

    if czy_wagi == True:
        labels = {i: label for i, label in enumerate(G.nodes())}

    print(f"\n\nDla wierzcholka {nr_w} mamy nastepujace miary:\nstopien: {stopien}, bliskosc: {bliskosc} ,posrednictwo: {posrednictwo}\n ")

    #dodaj ważony stopien


def ranking(G, czy_wagi):
    degCent = nx.degree_centrality(G)
    degCent_sorted = dict(sorted(degCent.items(), key=lambda item: item[1], reverse=True))
    betCent = nx.betweenness_centrality(G, normalized=True, endpoints=True)
    betCent_sorted = dict(sorted(betCent.items(), key=lambda item: item[1], reverse=True))
    closCent = nx.closeness_centrality(G)
    closCent_sorted = dict(sorted(closCent.items(), key=lambda item: item[1], reverse=True))

    print("Top 5 węzłów według centralności stopnia:")
    for i, (node, centrality) in enumerate(degCent_sorted.items()):
        if i >= 5:
            break
        print(f"{i + 1}. {node}: {centrality:.4f}")

    print("\nTop 5 węzłów według centralności bliskości:")
    for i, (node, centrality) in enumerate(closCent_sorted.items()):
        if i >= 5:
            break
        print(f"{i + 1}. {node}: {centrality:.4f}")

    print("\nTop 5 węzłów według centralności pośrednictwa:")
    for i, (node, centrality) in enumerate(betCent_sorted.items()):
        if i >= 5:
            break
        print(f"{i + 1}. {node}: {centrality:.4f}")


def miara_posrednictwa_dla_krawedzi(G):
    edge_betweenness = nx.edge_betweenness_centrality(G, normalized=True)
    return edge_betweenness


def ranking_krawedzi(G):
    edge_betweenness = miara_posrednictwa_dla_krawedzi(G)

    edge_betweenness_sorted = dict(sorted(edge_betweenness.items(), key=lambda item: item[1], reverse=True))

    print("\nTop 5 krawędzi według centralności pośrednictwa:")
    for i, (edge, centrality) in enumerate(edge_betweenness_sorted.items()):
        if i >= 5:
            break
        print(f"{i + 1}. Krawędź {edge}: {centrality:.4f}")


#print(G.degree())
#print(nx.closeness_centrality(G))
#print(nx.betweenness_centrality(G))

#wizualizacja(G)
#podstawowe_wlasnosci_grafu(G,czy_wagi)
#wlasnosci_wierzcholkow(G,czy_wagi)
#ranking(G, czy_wagi)
#ranking_krawedzi(G)

#print(nx.approximation.max_clique(G))

print("\n\n")
#print(nx.node_connectivity(G))
print("\n\n")
#print(nx.edge_connectivity(G))
print("\n\n")
print(list(nx.algorithms.articulation_points(G)))
print("\n\n")
print(list(nx.algorithms.bridges(G)))