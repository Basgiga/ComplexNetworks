import networkx as nx
import matplotlib.pyplot as plt
from networkx.algorithms import bipartite
import chardet
import numpy as np

rozprawy_limit = 7
rozprawy_count = 0

B = nx.Graph()
file_path = "wikiElec.txt"
with open(file_path, "r", encoding="ISO-8859-1") as f:
    lines = f.readlines()

current_election = None
for line in lines:
    if rozprawy_count >= rozprawy_limit:
        break

    line = line.strip()

    if line.startswith("E"):
        rozprawy_count += 1
        current_election = {}
        current_election['E'] = int(line.split("\t")[1])

    elif line.startswith("T"):
        current_election['T'] = line.split("\t")[1]

    elif line.startswith("U"):
        uid, username = line.split("\t")[1:3]
        current_election['U'] = (int(uid), username)
        B.add_node((int(uid), username), bipartite=0, role='kandydat')

    elif line.startswith("N"):
        nid, nname = line.split("\t")[1:3]
        current_election['N'] = (int(nid), nname)
        B.add_node((int(nid), nname), bipartite=0, role='nominator')
        B.add_edge((int(nid), nname), current_election['U'], relation='nominatowany')

    elif line.startswith("V"):
        parts = line.split("\t")
        vote = int(parts[1])
        voter_id, time, voter_name = int(parts[2]), parts[3], parts[4]
        voter_node = (voter_id, voter_name)
        B.add_node(voter_node, bipartite=1, role='glosujacy')
        B.add_edge(voter_node, current_election['U'], vote=vote, time=time)

print(f"liczba wierzcholkow: {B.number_of_nodes()}")
print(f"Number of edges: {B.number_of_edges()}")



def wizu():
    kandydaci = {n for n, d in B.nodes(data=True) if d['bipartite'] == 0}
    glosujacy = set(B) - kandydaci
    pos = {}
    pos.update((node, (i, 0)) for i, node in enumerate(kandydaci))
    pos.update((node, (i, 1)) for i, node in enumerate(glosujacy))

    plt.figure(figsize=(12, 8))
    nx.draw_networkx_nodes(B, pos, nodelist=kandydaci, node_color="lightblue", label="kandydaci/nominujacy")
    nx.draw_networkx_nodes(B, pos, nodelist=glosujacy, node_color="lightgreen", label="glosujacy")
    nx.draw_networkx_edges(B, pos, alpha=0.5)
    nx.draw_networkx_labels(B, pos, font_size=8)

    plt.legend()
    plt.title("dwudzielny Graf of wyborow wikipedyjnych")
    plt.axis("off")
    plt.show()




def projekcja_prosta(B, kategoria):
    projekcja = nx.Graph()
    wierzcholki = {n for n, d in B.nodes(data=True) if d['bipartite'] == kategoria}
    for w1 in wierzcholki:
        for w2 in wierzcholki:
            if w1 != w2 and len(set(B.neighbors(w1)) & set(B.neighbors(w2))) > 0:
                projekcja.add_edge(w1, w2)
    return projekcja

def projekcja_wazona(B, kategoria):
    projekcja = nx.Graph()
    wierzcholki = {n for n, d in B.nodes(data=True) if d['bipartite'] == kategoria}
    for w1 in wierzcholki:
        for w2 in wierzcholki:
            if w1 != w2:
                wspolni = len(set(B.neighbors(w1)) & set(B.neighbors(w2)))
                if wspolni > 0:
                    projekcja.add_edge(w1, w2, weight=wspolni)
    return projekcja

def projekcja_jaccarda(B, kategoria):
    projekcja = nx.Graph()
    wierzcholki = {n for n, d in B.nodes(data=True) if d['bipartite'] == kategoria}
    for w1 in wierzcholki:
        for w2 in wierzcholki:
            if w1 != w2:
                s1 = set(B.neighbors(w1))
                s2 = set(B.neighbors(w2))
                wspolni = len(s1 & s2)
                unia = len(s1 | s2)
                if wspolni > 0:
                    projekcja.add_edge(w1, w2, weight=wspolni / unia)
    return projekcja

def generuj_macierz_sasiedztwa(B, projekcja):
    nodes = list(projekcja.nodes())
    macierz = nx.to_numpy_array(projekcja, nodelist=nodes, weight='weight')
    return macierz, nodes

def graf_gesty(graf, threshold=3):
    # Usuwamy krawędzie o zbyt małej wadze (tylko krawędzie o wadze >= threshold)
    gesty_graf = nx.Graph()
    for u, v, data in graf.edges(data=True):
        if 'weight' in data and data['weight'] >= threshold:
            gesty_graf.add_edge(u, v, weight=data['weight'])
    return gesty_graf












import matplotlib.colors as mcolors
def wizualizuj_graf(graf, tytul="Projekcja"):
    fig, ax = plt.subplots(figsize=(12, 8))
    ax.set_facecolor('lavender')
    pos = nx.spring_layout(graf)
    edges = graf.edges(data=True)
    weights = [d['weight'] if 'weight' in d else 1 for _, _, d in edges]

    norm = mcolors.Normalize(vmin=min(weights), vmax=max(weights))
    edge_colors = [plt.cm.magma(norm(w)) for w in weights] #              lub magma_r

    edge_colors = [(r, g, b) for r, g, b, _ in edge_colors]

    edge_widths = [w for w in weights]

    nx.draw(
        graf, pos, with_labels=True, node_color="lightblue",
        edge_color=edge_colors, font_size=8, width=edge_widths, ax=ax
    )

    sm = plt.cm.ScalarMappable(cmap=plt.cm.magma, norm=norm) #              lub magma_r
    sm.set_array([])
    cbar = fig.colorbar(sm, ax=ax)
    cbar.set_label("waga krawedzi")

    ax.set_title(tytul)
    plt.show()

def wizualizuj_macierz_sasiedztwa(macierz, wezly):
    plt.figure(figsize=(10, 8))
    plt.imshow(macierz, cmap='Blues', interpolation='none')
    plt.colorbar(label="Waga krawędzi")
    plt.xticks(np.arange(len(wezly)), wezly, rotation=90)
    plt.yticks(np.arange(len(wezly)), wezly)
    plt.title("Macierz sąsiedztwa")
    plt.show()


def jazda():
    wizu()

    # Projekcja prosta
    proj_prosta = projekcja_prosta(B, kategoria=1)
    print("Liczba krawędzi w projekcji prostej:", proj_prosta.number_of_edges())
    wizualizuj_graf(proj_prosta, "Projekcja Prosta")

    # Projekcja ważona
    proj_wazona = projekcja_wazona(B, kategoria=1)
    print("Liczba krawędzi w projekcji ważonej:", proj_wazona.number_of_edges())
    wizualizuj_graf(proj_wazona, "Projekcja Ważona")

    proj_jaccarda = projekcja_jaccarda(B, kategoria=1)
    print("Liczba krawędzi w projekcji Jaccarda:", proj_jaccarda.number_of_edges())
    wizualizuj_graf(proj_jaccarda, "Projekcja Jaccarda")

    gesty_graf = graf_gesty(proj_wazona, threshold=3)
    print("Liczba krawędzi w gęstym grafie:", gesty_graf.number_of_edges())
    wizualizuj_graf(gesty_graf, "graf gesty")

    macierz, wezly = generuj_macierz_sasiedztwa(B, proj_prosta)
    wizualizuj_macierz_sasiedztwa(macierz, wezly)

jazda()